import init from './src/init.js';

export default init;
